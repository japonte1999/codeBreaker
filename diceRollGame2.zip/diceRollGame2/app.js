var scores = [0,0];
var currentScore = 0;
var currentPlayer = 0;
var limit = 100;

//document.querySelector('.dice').style.display = 'none';

document.getElementById('score-0').textContent = '0';
document.getElementById('score-1').textContent = '0';
document.getElementById('current-0').textContent = '0';
document.getElementById('current-1').textContent = '0';

document.querySelector('.set-lim').addEventListener('click', function(){
    alert("The game will reset if you reset the limit...");
    var userLimit;
    while(isNaN(userLimit)){
    userLimit = window.prompt("Enter new winning limit: ");
    if(userLimit === null){return;}
    }
    limit = userLimit;
    document.querySelector(".limit").textContent = "Current Limit: " + limit;
    resetGame();
})

document.querySelector(".btn-roll").addEventListener('click', function(){
    var dice1 = Math.floor(Math.random() *6 + 1);
    var dice2 = Math.floor(Math.random() *6 + 1);

    var dice1DOM = document.getElementById("dice1");
    dice1DOM.style.display = 'block';
    dice1DOM.src = "dice-"+ dice1 + ".png";

    var dice2DOM = document.getElementById("dice2");
    dice2DOM.style.display = 'block';
    dice2DOM.src = "dice-"+ dice2 + ".png";

    if(dice1 === 1 || dice2 === 1){
        nextPlayer();
    }else if(dice1 === 6 && dice2 ===6){
        document.getElementById("score-" + currentPlayer).textContent = 0;
        nextPlayer();
    }else{
        currentScore += (dice1 + dice2);
        document.getElementById("current-" + currentPlayer).textContent = currentScore;
    }

})

document.querySelector('.btn-hold').addEventListener('click', function(){
    scores[currentPlayer] += currentScore;
    document.getElementById('score-' + currentPlayer).textContent = scores[currentPlayer];
    if(scores[currentPlayer] >= limit){
        document.getElementById('name-' + currentPlayer).textContent = 'Winner!'
        document.getElementById("dice1").style.display = "none";
        document.getElementById("dice2").style.display = "none";
        document.querySelector('.player-'+ currentPlayer + '-panel').classList.add('winner');
        document.querySelector('.player-'+ currentPlayer + '-panel').classList.remove('active');
        document.querySelector(".btn-hold").disabled = true;
        document.querySelector(".btn-roll").disabled = true;

    }else{
        nextPlayer();
    }

})

document.querySelector('.btn-new').addEventListener('click', function(){ 
    resetGame();
})

function resetGame(){
    document.getElementById('name-' + currentPlayer).textContent = 'Player ' + currentPlayer;
    currentPlayer = 0;
    document.querySelector('.dice').style.display = 'none'; //Manipulate css. '.dice' a class instead of an id. setting its displaye to 'none', inline css

    document.getElementById('score-0').textContent = '0'; //Alternative to using query selector
    document.getElementById('score-1').textContent = '0';
    document.getElementById('current-0').textContent = '0';
    document.getElementById('current-0').textContent = '0';

    document.querySelector(".btn-hold").disabled = false;
    document.querySelector(".btn-roll").disabled = false;
    document.querySelector('.player-0-panel').classList.add('active'); // toggle used to turn classes on and off
    document.querySelector('.player-1-panel').classList.remove('active');
    document.querySelector('.player-'+ currentPlayer + '-panel').classList.remove('winner');
    
    currentPlayer = 0;
    scores[0] = 0;
    scores[1] = 0;
    roundScore = 0;
}
function nextPlayer(){
    currentPlayer === 0 ? currentPlayer = 1 : currentPlayer = 0;
    currentScore = 0;
     
    document.getElementById("current-0").textContent = '0';
    document.getElementById("current-1").textContent = '0';

    document.querySelector(".player-0-panel").classList.toggle("active");
    document.querySelector(".player-1-panel").classList.toggle("active");

}
